import pygame
import sys

# Initialize pygame
pygame.init()

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)

# Fonts
font = pygame.font.Font(None, 36)

# Create the screen object in fullscreen mode
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
screen_width, screen_height = screen.get_size()
pygame.display.set_caption('Psychology Revision Tool')

# Define a basic button class
class Button:
    def __init__(self, text, pos, action=None):
        self.text = text
        self.pos = pos
        self.action = action
        self.rect = pygame.Rect(pos[0], pos[1], 200, 50)
        self.color = BLUE

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect)
        text_surface = font.render(self.text, True, WHITE)
        screen.blit(text_surface, (self.rect.x + 10, self.rect.y + 10))

    def is_clicked(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

# Pages
class Page:
    def __init__(self, text=None):
        self.text = text

    def draw(self, screen):
        screen.fill(WHITE)
        if self.text:
            text_surface = font.render(self.text, True, BLACK)
            screen.blit(text_surface, (50, 50))

# Navigation system
class Navigation:
    def __init__(self):
        self.pages = {}
        self.current_page = None

    def add_page(self, name, page):
        self.pages[name] = page

    def go_to_page(self, name):
        self.current_page = self.pages[name]

    def draw(self, screen):
        if self.current_page:
            self.current_page.draw(screen)

# Instantiate navigation system and pages
navigation = Navigation()

# Home Page
navigation.add_page("home", Page(text="Welcome to Psychology Revision"))

# Year 1 Topic Pages
topics = ["social_influence", "memory", "attachment", "psychopathology", "approaches", "biopsych"]

for topic in topics:
    navigation.add_page(f"year1_{topic}", Page(text=topic.replace("_", " ").capitalize()))
    navigation.add_page(f"year1_{topic}_info", Page(text=f"{topic.replace('_', ' ').capitalize()} - Info"))
    navigation.add_page(f"year1_{topic}_eval", Page(text=f"{topic.replace('_', ' ').capitalize()} - Eval"))
    navigation.add_page(f"year1_{topic}_questions", Page(text=f"{topic.replace('_', ' ').capitalize()} - Questions"))

# Function to create subpage buttons for a specific topic
def create_subpage_buttons(topic):
    global buttons
    buttons = [
        back_button,
        Button("Info", (screen_width // 4 - 100, screen_height - 100), lambda: navigation.go_to_page(f"year1_{topic}_info")),
        Button("Eval", (screen_width // 2 - 100, screen_height - 100), lambda: navigation.go_to_page(f"year1_{topic}_eval")),
        Button("Questions", (3 * screen_width // 4 - 100, screen_height - 100), lambda: navigation.go_to_page(f"year1_{topic}_questions")),
    ]

# Function to create Year 1 buttons
def show_year1_buttons():
    global buttons
    buttons = [
        home_button,
        Button("Social Influence", (50, screen_height - 300), lambda: create_subpage_buttons("social_influence")),
        Button("Memory", (50, screen_height - 240), lambda: create_subpage_buttons("memory")),
        Button("Attachment", (50, screen_height - 180), lambda: create_subpage_buttons("attachment")),
        Button("Psychopathology", (50, screen_height - 120), lambda: create_subpage_buttons("psychopathology")),
        Button("Approaches", (50, screen_height - 60), lambda: create_subpage_buttons("approaches")),
        Button("Biopsychology", (50, screen_height - 360), lambda: create_subpage_buttons("biopsych"))
    ]

# Function to create Year 2 buttons (example with Temp button)
def show_year2_buttons():
    global buttons
    buttons = [
        home_button,
        Button("Temp", (screen_width // 2 - 100, screen_height - 100), lambda: navigation.go_to_page("year2_temp")),
    ]

# Initial buttons
home_button = Button("Home", (screen_width // 2 - 100, screen_height - 100), lambda: navigation.go_to_page("home"))
back_button = Button("Back", (screen_width // 2 - 100, screen_height - 160), show_year1_buttons)  # Back button
year1_button = Button("Year 1", (screen_width // 3 - 100, screen_height - 100), show_year1_buttons)
year2_button = Button("Year 2", (2 * screen_width // 3 - 100, screen_height - 100), show_year2_buttons)

buttons = [year1_button, year2_button]

# Main loop
running = True
while running:
    screen.fill(WHITE)
    navigation.draw(screen)

    for button in buttons:
        button.draw(screen)

    pygame.display.flip()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            for button in buttons:
                if button.is_clicked(mouse_pos):
                    button.action()

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
